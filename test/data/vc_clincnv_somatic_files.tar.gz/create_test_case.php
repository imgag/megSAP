<?php
require_once("/mnt/users/bioinf/megSAP/src/Common/all.php");



$panel = "ssSC_v5";
$covdir =  "/mnt/storage2/GRCh38/share/data/coverage/";

copy("/mnt/storage2/GRCh38/share/data/enrichment/ssSC_v5.bed", "target_region.bed");
copy("/mnt/storage2/GRCh38/share/data/coverage/off_target_beds/{$panel}.bed", "off_target.bed");

file_put_contents("processing_system.ini",
"name_short = \"ssSC_v4HS\"
name_manufacturer = \"Sure Select HS Somatic Cancer Panel v4\"
target_file = \"target_region.bed\"
adapter1_p5 = \"AGATCGGAAGAGCACACGTCTGAACTCCAGTCAC\"
adapter2_p7 = \"AGATCGGAAGAGCGTCGTGTAGGGAAAGAGTGT\"
shotgun = 1
umi_type = \"n/a\"
type = \"Panel\"
build = \"GRCh38\"");


$dirs = ["bafs", "cov-normal", "cov-normal_off_target", "cov-tumor", "cov-tumor_off_target"];
foreach($dirs as $dir)
{
	if(!is_dir($dir)) mkdir($dir);
}

$ids = array(
	"DX207309_01" => "DX206942_01",
	"DX207311_01" => "DX207344_01",
	"DX207453_01" => "DX207232_01",
	"DX207454_01" => "DX207230_01",
	"DX207506_01" => "DX206721_01",
	"DX207507_01" => "DX207452_01",
	"DX207509_01" => "DX207336_01",
	"DX207510_01" => "DX207245_01",
	"DX207511_02" => "DX207172_01",
	"DX207512_01" => "DX206760_02",
	"DX207513_01" => "DX206391_01",
	"DX207514_01" => "DX207181_01",
	"DX207566_01" => "DX207362_01",
	"DX207679_01" => "DX207352_01",
	"DX207680_01" => "DX207183_01",
	"DX207681_01" => "DX207319_01",
	"DX207682_01" => "DX206737_01",
	"DX207683_01" => "DX206592_01",
	"DX207684_01" => "DX207932_01",
	"DX207685_01" => "DX207190_01"
);

foreach($ids as $tid => $nid)
{
	if( !file_exists("bafs/{$nid}.tsv") ) copy("{$covdir}/{$panel}_bafs/{$nid}.tsv", "bafs/{$nid}.tsv");
	if( !file_exists("bafs/{$tid}.tsv") ) copy("{$covdir}/{$panel}_bafs/{$tid}.tsv", "bafs/{$tid}.tsv");
	
	if( !file_exists("cov-normal/{$nid}.cov") ) copy("{$covdir}/{$panel}/{$nid}.cov", "cov-normal/{$nid}.cov");
	if( !file_exists("cov-normal_off_target/{$nid}.cov") ) copy("{$covdir}/{$panel}_off_target/{$nid}.cov", "cov-normal_off_target/{$nid}.cov");
	if( !file_exists("cov-tumor/{$tid}.cov") ) copy("{$covdir}/{$panel}-tumor/{$tid}.cov", "cov-tumor/{$tid}.cov");
	if( !file_exists("cov-tumor_off_target/{$tid}.cov") ) copy("{$covdir}/{$panel}-tumor_off_target/{$tid}.cov", "cov-tumor_off_target/{$tid}.cov");
}


//rename samples
$i = 0;

$list = array();
$list[] = "##THIS FILE CONTAINS TUMOR AND NORMAL IDS OF PROCESSING SYSTEM ssSC_v4HS";
$list[] = "#tumor_id,normal_id";


function replace_id($in, $id_old, $id_new)
{
	$content = file_get_contents($in);

	$content = str_replace($id_old,$id_new,$content);
	
	file_put_contents($in, $content);
}

foreach($ids as $tid => $nid)
{
	$new_tid = sprintf("DX%'.06d_01",$i);
	$new_nid = sprintf("DX%'.06d_02",$i);
	
	exec2("mv bafs/{$tid}.tsv bafs/{$new_tid}.tsv");
	exec2("mv bafs/{$nid}.tsv bafs/{$new_nid}.tsv");
	
	exec2("mv cov-normal/{$nid}.cov cov-normal/{$new_nid}.cov");
	replace_id("cov-normal/{$new_nid}.cov",$nid, $new_nid);
	
	exec2("mv cov-normal_off_target/{$nid}.cov cov-normal_off_target/{$new_nid}.cov");
	replace_id("cov-normal_off_target/{$new_nid}.cov",$nid, $new_nid);
	
	exec2("mv cov-tumor/{$tid}.cov cov-tumor/{$new_tid}.cov");
	replace_id("cov-tumor/{$new_tid}.cov",$tid, $new_tid);
	 
	exec2("mv cov-tumor_off_target/{$tid}.cov cov-tumor_off_target/{$new_tid}.cov");
	replace_id("cov-tumor_off_target/{$new_tid}.cov",$tid, $new_tid);
	
	$list[] = "{$new_tid},{$new_nid}";
	
	++$i;
}
file_put_contents("cov-tumor/list_tid-nid.csv", implode("\n", $list) );


?>